<style>
	body{
		 background-color:#e6fff2;
	}
	#set {
	 margin:auto;
	 width:50%;
	 text-align:center;

	 }
</style>

<?php
//menuInfo.php

echo '<div id ="set" style="line-height: 1.8;">';

echo '<form action="processMenu.php" method="post">';
echo '<fieldset><legend>Enter Menu Information:</legend>';
echo 'Menu Name:';
echo '<input type="text" name="menuName" required>';
echo '<br>Menu Type:';
echo '<input type="text" name="menuType" required>';
echo '<br>Menu price :';
echo '<input type="text" name="menuPrice">';
echo '<br>Menu Quantity :';
echo '<input type="text" name="menuQuantity">';

echo '<br><br><input type="submit" name="saveNewMenuButton" value="Save">';
echo '<input type ="reset" name="resetButton" value="reset">';

echo '</fieldset>';
echo '</form>';
echo '</div>';
?>